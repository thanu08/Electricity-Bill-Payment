package com.ebp.in.entity;
/*
public enum ConnectionStatus {
    ACTIVE,INACTIVE;
}
*/