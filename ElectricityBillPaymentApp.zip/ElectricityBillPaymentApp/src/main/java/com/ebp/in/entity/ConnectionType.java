package com.ebp.in.entity;


public enum ConnectionType {
	
	NON_INDUSTRIAL, INDUSTRIAL, AGRICULTURAL;

}
