package com.ebp.in.controller;

import java.util.List;

import javax.validation.Valid;

import com.ebp.in.entity.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ebp.in.entity.Connection;
//import com.ebp.in.entity.Customer;
import com.ebp.in.exception.NoSuchConnectionException;
import com.ebp.in.exception.NoSuchCustomerException;
import com.ebp.in.service.IConnectionService;

//@CrossOrigin("*")
@RestController
@RequestMapping(value =  "/connection")
public class ConnectionController {
	
	@Autowired
	private IConnectionService connectionService;

	/*
        URL    : localhost:8080/connection/newRequest
        METHOD : POST
     */

	
	@PostMapping(value="/newRequest")
	public ResponseEntity<Connection> newConnectionRequest(@Valid @RequestBody Connection newConnection)
	{
		Connection requestedConnection= connectionService.newConnectionRequest(newConnection);
		return new ResponseEntity<Connection>(requestedConnection,HttpStatus.CREATED);
	}

	/*
        URL    : localhost:8080/connection/consumernumber/{consumerNumber}
        METHOD : GET
     */

	
/*	@GetMapping(value = "/consumernumber/{consumerNumber}")
	public ResponseEntity<Customer> searchCustomerByConsumerNumber(@PathVariable Long consumerNumber) throws NoSuchCustomerException
	{
		Customer cn=connectionService.searchCustomerByConsumerNumber(consumerNumber);
		return new ResponseEntity<Customer>(cn,HttpStatus.OK);
	}*/
/*
	@PutMapping("/modifyConnectionAddress")
	public ResponseEntity<Connection> modifyConnectionAddress(@RequestBody Connection connection)
	{
		Connection modifyConnectionAddress=connectionService.modifyConnectionAddress(connection);
		return new ResponseEntity<Connection>(modifyConnectionAddress,HttpStatus.CREATED);
	}
	*/

	/*
        URL    : localhost:8080/connection/villageName/{village}
        METHOD : GET
     */


	@GetMapping(value="/villageName/{village}")
	public ResponseEntity<List<Connection>> searchConnectionsByVillage(String village)throws NoSuchCustomerException
	{
		List<Connection> connectionByVillage=connectionService.searchConnectionsByVillage(village);
		return new ResponseEntity<List<Connection>>(connectionByVillage,HttpStatus.OK);				
	}

	/*
        URL    : localhost:8080/connection/taluka/{taluk}
        METHOD : GET
     */


	@GetMapping(value="/taluka/{taluk}")
	public ResponseEntity<List<Connection>> searchConnectionsByTaluk(String taluk)throws NoSuchCustomerException
	{
		List<Connection> connectionByTaluk=connectionService.searchConnectionsByTaluk(taluk);
		return new ResponseEntity<List<Connection>>(connectionByTaluk,HttpStatus.OK);
	}

	/*
        URL    : localhost:8080/connection/district/{districtName}
        METHOD : GET
     */


	@GetMapping(value="/district/{districtName}")
	public ResponseEntity<List<Connection>> searchConnectionsByDistrict(String district)throws NoSuchCustomerException
	{
		List<Connection> connectionByDistrict=connectionService.searchConnectionsByDistrict(district);
		return new ResponseEntity<List<Connection>>(connectionByDistrict,HttpStatus.OK);				
	}


	/*
        URL    : localhost:8080/connection/pincode/{pincode}
        METHOD : GET
     */

	@GetMapping(value="/pincode/{pincode}")
	public ResponseEntity<List<Connection>> searchConnectionsBypincode(String pincode)throws NoSuchCustomerException
	{
		List<Connection> connectionByPincode=connectionService.searchConnectionsByPincode(pincode);
		return new ResponseEntity<List<Connection>>(connectionByPincode,HttpStatus.OK);				
	}



	
	
	
	
	
}

